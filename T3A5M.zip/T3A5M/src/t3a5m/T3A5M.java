package t3a5m;

import java.util.Scanner;

public class T3A5M {

       public static void main(String[] args) {
        menu();
    }
       public static void menu(){
           cuenta cuenta = new cuenta ();
           Scanner scanner = new Scanner (System.in);
           
           System.out.println("BIENVENIDO A BANCO X\n"
                   + "1. consultar saldo\n"
                   + "2. consultar estado de cuenta\n"
                   + "3. Retirar efectivo\n"
                   + "4. otras opciones\n"
                   + "5. Salir"
                   + "\n\nElija una operaci�n");
           
           int operacion = scanner.nextInt();
           
           switch (operacion){
               case 1: 
                   cuenta.consultarSaldo();
                   break;
               case 2:
                   cuenta.estadoDeCuenta();
                   break;
               case 3:
                   cuenta.retirarEfectivo();
                   break;
               case 4: 
                   System.out.println("1. Seguros\n"
                           + "2. Creditos\n\n"
                           + "Elija uno:");
                   int opcion = scanner.nextInt();
                   switch (opcion) {
                       case 1 :
                           cuenta.seguros();
                       break;
                       case 2 :
                           cuenta.creditos();
                           break;
                       default:
                           System.err.println("Elija una opci�n validad");
                           break;
                   }
                   break;
              
                   
                  
           }
       }
    
}
